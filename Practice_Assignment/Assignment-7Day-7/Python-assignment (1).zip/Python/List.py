l = [1,2,3,4,5,3]
l.append(6)
print(l)
list=[7,8]
l.extend(list)
print(l)
l.insert(2,10) # insert at position 2 value 10
print(l)
l.remove(10)
print(l)
pop_element=l.pop(1) #pop(position of a value to be removed)
print("poped elemnt: ",pop_element)
print(l)
count = l.count(3)
print(count)
l.sort()
print(l)
l.reverse()
print(l)