#Mapping function
#A mapping function typically refers to a function that transforms or maps elements from one set to another. In Python, the map() function is commonly used for this purpose. It applies a specified function to all items in an input iterable and returns an iterable of the results.


numbers = [1, 2, 3, 4, 5]
squared_numbers = map(lambda x: x**2, numbers)
print(list(squared_numbers)) 



#String Function
#String functions in Python are methods that operate on strings.

my_string = "Hello, World!"
print(my_string.upper())      
print(my_string.find("World")) #it will give the position
print(my_string.replace("Hello", "Hi")) 

#Number Function


x = 5
print(abs(x))      
print(pow(x, 2))     #power
print(round(3.14159)) 

#Date and Time Function
from datetime import datetime, timedelta

current_date = datetime.now()
print(current_date)                 
future_date = current_date + timedelta(days=7)
print(future_date.strftime("%Y-%m-%d"))  

#Python Functions
#Functions in Python are blocks of reusable code that perform a specific task. They are defined using the def keyword.

def greet(name):
    return f"Hello, {name}!"

print(greet("Alice")) 

#Default Argument Values
#Python functions can have default values for their parameters. If a value is not provided for a parameter, the default value is used.

def greet(name="Guest"):
    return f"Hello, {name}!"

print(greet())        
print(greet("Alice"))  

#Keyword Arguments
#You can pass arguments to a function by specifying the parameter names along with the values. This is known as using keyword arguments.

def greet(greeting, name):
    return f"{greeting}, {name}!"

print(greet(name="Alice", greeting="Hi"))  

#Special parameters
#Special parameters in Python functions include *args (arbitrary argument lists) and **kwargs (arbitrary keyword argument dictionaries).

def my_function(*args, **kwargs):
    print(args)   
    print(kwargs) 

my_function(1, 2, 3, name="Alice", age=30)

#Arbitrary Argument Lists
#Arbitrary argument lists allow a function to accept any number of positional arguments.

def sum_all(*args):
    return sum(args)

result = sum_all(1, 2, 3, 4)
print(result)

#Lambda Expressions
#Lambda expressions are a concise way to create anonymous functions (functions without a name).

square = lambda x: x**2
print(square(4)) 
