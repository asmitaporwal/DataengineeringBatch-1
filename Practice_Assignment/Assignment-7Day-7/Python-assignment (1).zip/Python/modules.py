#Python Modules

#User-Defined Modules:
#we can create our own modules by saving Python code in a separate file and then importing it into our script.
import my_module
my_module.greet("Asmita")

#Executing modules as scripts
#You can use the if __name__ == "__main__": block to check whether the Python script is being run as the main program or if it is being imported as a module.
def greet(name):
    print(f"Hello, {name}!")

if __name__ == "__main__":
    # Code to run if the module is executed as a script
    greet("Bob")

#Standard Modules
#Python comes with a set of standard modules that provide additional functionality. You can use them by importing them into your script.

import math

result = math.sqrt(25)
print(result) 

#Packages
#A package is a way of organizing related modules into a single directory hierarchy. Packages are created by placing multiple module files in a directory that includes a special file called __init__.py.

#Importing * From a Package
#When importing all modules from a package using *, the __init__.py file can specify what gets imported when the package is imported.


#Intra-package References
#You can reference other modules within the same package using relative imports.

#Packages in Multiple Directories
#Python allows you to organize packages across multiple directories. Each directory containing packages must also include an __init__.py file.