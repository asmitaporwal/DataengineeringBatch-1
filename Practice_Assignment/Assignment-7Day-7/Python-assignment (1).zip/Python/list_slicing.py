my_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Basic slicing
slice1 = my_list[2:5]  # Elements from index 2 to 4 (5 is exclusive)
print(slice1)         

# Omitting start or stop
slice2 = my_list[:5]   # Elements from the beginning to index 4
slice3 = my_list[5:]   # Elements from index 5 to the end
print(slice2)         
print(slice3)        

# Negative indices
slice4 = my_list[-4:-1]  # Elements from the 4th last to the 2nd last
print(slice4)           

# Slicing with step
slice5 = my_list[1:8:2]  # Elements from index 1 to 7 with a step of 2
print(slice5)          

# Omitting start, stop, and using step
slice6 = my_list[::2]    # Every second element from the beginning to the end
print(slice6)           

# Reversing a list
reversed_list = my_list[::-1]
print(reversed_list)    