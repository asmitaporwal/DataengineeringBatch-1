#variables
x = 5         # x is a variable with the value 5
name = "John" # name is a variable with the value "John"
pi = 3.14     # pi is a variable with the value 3.14
is_true = True # is_true is a variable with the value True

#arithmetic operators
a = 10
b = 3

addition = a + b        
subtraction = a - b    
multiplication = a * b 
division = a / b       
modulo = a % b          # Modulo (remainder after division)
exponentiation = a ** b # Exponentiation
floor_division = a // b # Floor division (returns the quotient, discarding any remainder)
print(addition,subtraction,multiplication,division,modulo,exponentiation,floor_division)

#comparison operators
x = 5
y = 10

equal = x == y     
not_equal = x != y  
greater_than = x > y 
less_than = x < y    
greater_equal = x >= y 
less_equal = x <= y    
print(equal,not_equal,greater_than,less_than,greater_equal,less_equal)

#logical operators
p = True
q = False

logical_and = p and q  # Logical AND
logical_or = p or q    # Logical OR
logical_not = not p    # Logical NOT
print(logical_and,logical_not,logical_or)

#assignment operators
x = 5

x += 3
print(x)  
x -= 2 
print(x)  
x *= 4
print(x)  
x /= 2  
print(x)