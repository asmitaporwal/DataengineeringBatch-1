# Creating a set
my_set = {1, 2, 3, 4, 5}
print(my_set)  

# Using the set() constructor
another_set = set([3, 4, 5, 6, 7])
print(another_set)  

# Set operations
set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}

union_set = set1 | set2  # Union
print(union_set)  

intersection_set = set1 & set2  # Intersection
print(intersection_set)

difference_set = set1 - set2  # Difference
print(difference_set)  

#add method
my_set.add(6)
print(my_set)

#remove  Removes the specified element from the set. Raises a KeyError if the element is not present.
my_set.remove(3)
print(my_set) 

#discard  Removes the specified element from the set if present. Does not raise an error if the element is not found
my_set.discard(2)
print(my_set) 

#pop(): Removes and returns an arbitrary element from the set. Raises a KeyError if the set is empty.
popped_element = my_set.pop()
print(popped_element)

#clear(): Removes all elements from the set, making it empty
my_set.clear()
print(my_set)  

