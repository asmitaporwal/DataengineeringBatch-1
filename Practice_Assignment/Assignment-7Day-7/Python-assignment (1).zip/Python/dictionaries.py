#dictionary
my_dict = {
    "name": "John",
    "age": 25,
    "city": "New York"
}

print(my_dict["name"])  
print(my_dict["age"])  
print(my_dict["city"])  

#get method
age = my_dict.get("age")
print(age)

salary = my_dict.get("salary", 0)
print(salary)

#key and values method
all_keys = my_dict.keys()
print(all_keys)

all_values = my_dict.values()
print(all_values)

#all items
all_items = my_dict.items()
print(all_items)

#update
new_data = {"salary": 50000, "gender": "Male"}
my_dict.update(new_data)
print(my_dict)

#pop specific item
removed_value = my_dict.pop("age")
print(removed_value) 

#pop item
last_item = my_dict.popitem()
print(last_item)

