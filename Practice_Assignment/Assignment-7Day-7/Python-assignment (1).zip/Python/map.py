#"map" can refer to both a function (map() function) and a data structure (dict type).

#Map as a Function
numbers = [1, 2, 3, 4, 5]
squared_numbers = map(lambda x: x**2, numbers)
print(list(squared_numbers))  

#A dict (dictionary) in Python is often referred to as a map. It is an unordered collection of key-value pairs.

#dictionary (map)
my_map = {
    "name": "Alice",
    "age": 30,
    "city": "Wonderland"
}


print(my_map["name"])  
print(my_map["age"])   
print(my_map["city"]) 



