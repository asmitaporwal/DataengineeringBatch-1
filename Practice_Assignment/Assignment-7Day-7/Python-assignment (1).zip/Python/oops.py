#OOPS
#Object-Oriented Programming is a programming paradigm that uses objects to organize code. Objects can encapsulate data and behavior, providing a modular and structured approach to software development.

#Class and Object
#Class: A class is a blueprint for creating objects. It defines attributes and methods that the objects of the class will have.
#Object: An object is an instance of a class. It represents a real-world entity and has attributes and behaviors defined by the class.

class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age
        
    def bark(self):
        print("Woof!")

my_dog = Dog("Buddy", 3)
print(my_dog.name)  
my_dog.bark()      


#Access Specifiers
#Access specifiers in Python determine the visibility of attributes and methods within a class.
#Public: Attributes and methods are accessible from outside the class.
#Private: Attributes and methods are accessible only within the class.

class MyClass:
    def __init__(self):
        self.public_variable = "I am public"
        self.__private_variable = "I am private"
        
    def public_method(self):
        print("Public method")
        
    def get_private_variable(self):
        return self.__private_variable
       

new_class=MyClass()
print(new_class.public_variable)
print(new_class.public_method())
p=new_class.get_private_variable()
print(p)


#Constructor
#A constructor is a special method that gets executed when an object is created. In Python, the constructor is named __init__.
class Car:
    def __init__(self, make, model):
        self.make = make
        self.model = model

my_car = Car("Toyota", "Camry")

#Inheritance
#Inheritance allows a class (subclass or derived class) to inherit properties and behaviors from another class (base class or superclass).
class Animal:
    def speak(self):
        print("Animal speaks")

class Dog(Animal):
    def bark(self):
        print("Dog barks")

my_dog = Dog()
my_dog.speak() 
my_dog.bark()  

#example 2
class Bird:
    def __init__(self,name):
        self.name=name

    def print_info(self):
        print("The bird name is : ",self.name)

    def fly(self):
        print("The bird can fly ")

class Parrot(Bird):
    def __init__(self, name,color,character):
        super().__init__(name)  
        self.color=color
        self.character=character

   #override method

    def print_info(self):
        print("The bird is :",self.name)
        print("color of bird is :",self.color)
        print("charater of bird is :",self.character)                            

obj_parrot=Parrot('Parrot','Green','good')
obj_parrot.fly()
obj_parrot.print_info()

#types of inheritance
#Single inheritance
#In single inheritance you can derive a (child) class from a single parent class.
class father:
    def quality(self):
        print("inside father class")
        print("father has intelligence and  deep thinking power")
        print("\n")
class son(father):
    def aim(self):
        print("inside son class")
        print("child wants to be software enginner")
        print("\n")
ram=son()
ram.quality()
ram.aim()  

#Multilevel inheritance
#Python allows multilevel inheritance. In it a new derived class inherits the properties of the base class. Actually a class is permitted to inherit from a base class or child class or derived class. So, the classes are inherited at multiple individual levels.
class grandfather:
    def gf_quality(self):
        print("inside gf class")
        print("gf was a honest person")
        print("\n")
wazed=grandfather()
class father(grandfather):
    def father_quality(self):
        print("inside father class")
        print("father has intelligence and  deep thinking power")
        print("\n")

fazul=father()

class son(father):
    def aim(self):
        print("inside son class")
        print("child wants to be software enginner")
        print("\n")
ram=son()
ram.gf_quality()
ram.father_quality()
ram.aim()  

#Multiple Inheritance
#In it you can inherit the features of more classes into a single class. Suppose we have two parents classes (Father and Mother) and one child class that is derived form two parents classes.
class father():
    def father_quality(self):
        print("inside father class")
        print("father has intelligence and  deep thinking power")
       
    def father_nature(self):
        print("inside father class")
        print("father is strict in principle")
        print("\n")    

fazul=father()
class Mother():
    def mother_quality(self):
        print("inside mother class")
        print("mother is a good cook")
      
    def mother_nature(self):
        print("inside mother class")
        print("mother has soft mind") 
        print("\n")   

fazul=father()

class son(father,Mother):
    def aim(self):
        print("inside son class")
        print("child wants to be software enginner")
        print("\n")
ram=son()
ram.mother_quality()
ram.father_quality()
ram.aim() 

#Hierarchical inheritance
#In it you can drive multiple classes from a single base class. In the following illustration we have one patent class and two derived classes.
class father():
    def father_quality(self):
        print("inside father class")
        print("father has intelligence and  deep thinking power")
       
    def father_nature(self):
        print("inside father class")
        print("father is strict in principle")
        print("\n")
class son1(father):
    def aim(self):
        print("inside son1 class")
        print("child wants to be software enginner")
        print("\n")

ram=son1()
ram.father_nature()
ram.father_quality()
ram.aim()        
class son2(father):
    def aim(self):
        print("inside son2 class")
        print("child wants to be a cook ")
        print("\n")
shyam=son2()
shyam.father_quality()

#Polymorphism
#Polymorphism allows objects of different types to be treated as objects of a common type. It can be achieved through method overloading or method overriding.
class Cat(Animal):
    def speak(self):
        print("Cat meows")

def animal_sound(animal):
    animal.speak()

my_cat = Cat()
animal_sound(my_dog)
animal_sound(my_cat)  

#Method Overriding
#Method overriding occurs when a subclass provides a specific implementation for a method that is already defined in its superclass.
class Bird(Animal):
    def speak(self):
        print("Bird sings")

my_bird = Bird()
my_bird.speak()  

#File handling
#File handling in Python involves reading from and writing to files. The open() function is commonly used for file operations.
# Writing to a file
with open("example.txt", "w") as file:
    file.write("Hello, Asmita!")

# Reading from a file
with open("example.txt", "r") as file:
    content = file.read()
    print(content)  

#Exception Handling
#Exception handling in Python involves using try, except, else, and finally blocks to handle errors and exceptions gracefully.
#Exceptions: Exceptions are raised when the program is syntactically correct, but the code results in an error. This error does not stop the execution of the program, however, it changes the normal flow of the program.
try:
    result = 10 / 0
except ZeroDivisionError:
    print("Cannot divide by zero")
else:
    print(result)
finally:
    print("Execution completed")


#Encapsulation 
class Base:
    def __init__(self):
        self.a = "HexaforHexa"
        self.__c = "HexaforHexa"

class Derived(Base):
    def __init__(self):
 
        # Calling constructor of
        # Base class
        Base.__init__(self)
        print("Calling private member of base class: ")
        # print(self.__c)
obj1 = Base()
obj2 = Derived()
print(obj1.a)


