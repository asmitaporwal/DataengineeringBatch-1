# if-else
def check_number(number):
    if number > 0:
        print("The number is positive.")
    elif number < 0:
        print("The number is negative.")
    else:
        print("The number is zero.")

if __name__ == "__main__":
    user_input = int(input("Enter a number: "))
    check_number(user_input)


# for loop

for i in range(5):
    print(i)    

# while
j=1
while j<5:
    print(j)
    j +=1   

# Nested loop 
for i in range(3):
    for j in range(3): 
        print(f"({i}, {j})")

# break,continue and pass
        
for i in range(10):
    if i == 5:
        break
    print(i)

for i in range(10):
    if i == 5:
        continue
    print(i)

for i in range(10):
   pass

# input and output

name = input("Enter your name: ")
print("Hello, " + name + "!")
