# import csv
# rows = []
# with open("new_data1.csv", 'r') as file:
#    csvreader = csv.reader(file)
#    header = next(csvreader)
#    for row in csvreader:
#        rows.append(row)
# print(header)
# print(rows)

with open('new_data1.csv') as file:
    content = file.readlines()
header = content[:1]
rows = content[3:]
print(header)
print(rows)